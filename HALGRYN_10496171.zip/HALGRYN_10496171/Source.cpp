// Source.cpp
// CSP2104 - OOC++
// Assignment 1 Deliverable 1
// Abrie Halgryn - 10496171

#include <iostream>
#include "Dictionary_Part01.h"
#include "Dictionary_Part02.h"

using namespace std;

//main of the function
int main()
{
	Dictionary_Part01 newDictionary;
	newDictionary.loadDictionary(); //loads dictionary
	Dictionary_Part02 newDictionary02;


	bool loop = 1;
	while (loop) //while loop to be able to return to the main menu once a task has been excecuted
	{

		int choice = newDictionary.getChoice(); //this is used for error checking.

		if (choice == 1)
		{
			newDictionary.searchForWord(); //Search for a word
			newDictionary.clearScreen(); // clear screen

		}

		else if (choice == 2)
		{
			newDictionary.moreThanThreeZs(); //Find the word(s) with more than three z's."
			newDictionary.clearScreen();
		}

		else if (choice == 3)
		{
			newDictionary.qWithNoU(); //List the words that have a 'q' without a following 'u' eg. 'Iraqi."
			newDictionary.clearScreen();
		}

		else if (choice == 4)
		{
			newDictionary02.nounAndVerb(newDictionary); // the following functions accept the newdictionary object so that the loaded vector can be used
			newDictionary.clearScreen();
		}

		else if (choice == 5)
		{
			newDictionary02.checkForPalindromes(newDictionary);
			newDictionary.clearScreen();
		}

		else if (choice == 6)
		{
			newDictionary02.checkForAnagram(newDictionary);
			newDictionary.clearScreen();
		}

		else if (choice == 7)
		{
			newDictionary02.guessingGame(newDictionary);
			newDictionary.clearScreen();
		}


		else if (choice == 8) // if the user whishes to quit the program.
		{
			cout << "Goodbye" << endl;
			loop = 0;
			newDictionary.clearScreen();
		}

		else
		{
			cout << "Invalid input, please try again." << endl;
			newDictionary.clearScreen();
			choice = newDictionary.getChoice();
		}



	}
	return 0;
}
