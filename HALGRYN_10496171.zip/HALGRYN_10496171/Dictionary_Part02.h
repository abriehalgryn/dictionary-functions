// Dictionary_Part02.h

#ifndef DICTIONARYPART02_H
#define DICTIONARYPART02_H

#include <iostream>
#include<string>
#include <vector>
#include "Word.h"

//incudes the neccesary modules for this program to work
using namespace std;


//creates a class called Dictionary_Part01 as per assignment requriements
class Dictionary_Part02
{
private:
	// sets appropriate fields
	//Dictionary_Part01 vectors;


public:
	// the following functions accept the newdictionary object so that the loaded vector can be used
	void nounAndVerb(Dictionary_Part01);
	void checkForPalindromes(Dictionary_Part01);
	void checkForAnagram(Dictionary_Part01);
	void guessingGame(Dictionary_Part01);

};

#endif