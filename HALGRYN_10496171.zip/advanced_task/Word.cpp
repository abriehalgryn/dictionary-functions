// Word.cpp
#include<string>
#include "Word.h"


string Word::getName()
{
	return name;
}