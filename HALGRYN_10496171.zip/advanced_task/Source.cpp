#include <iostream>
#include "trigram.h"

int main()
{
	trigram new_trigram;
	new_trigram.loadDictionary();
	new_trigram.loadTextFile();
	new_trigram.calculatePercentages();
	
	
	bool loop = 1;
	while (loop) //while loop to be able to return to the main menu once a task has been excecuted
	{
		int choice = new_trigram.getChoice(); //this is used for error checking.

		if (choice == 1)
		{
			new_trigram.displayTopThree(); // display top three words
			new_trigram.clearScreen(); // clear screen

		}

		else if (choice == 2)
		{
			new_trigram.generateRandomWords(); // generate random words"
			new_trigram.clearScreen();
		}

		else if (choice == 3) // if the user whishes to quit the program.
		{
			cout << "Goodbye" << endl;
			loop = 0;
			new_trigram.clearScreen();
		}

		else
		{
			cout << "Invalid input, please try again." << endl;
			new_trigram.clearScreen();
			choice = new_trigram.getChoice();
		}
	}
	return 0;
}